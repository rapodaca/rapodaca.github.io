# Very crude installer. Use at your own risk!
# Change Installer.ob_dir and Installer.ob_version to match
# your configuration.

class Installer
  @@ob_dir='/usr/local'
  @@ob_version = '2.0'
  @@ob_flag="--with-openbabel-include='#{@@ob_dir}/include/openbabel-#{@@ob_version}/openbabel'"
  @@ob_version_flag="--with-openbabel-#{@@ob_version}-include='#{@@ob_dir}/include/openbabel-#{@@ob_version}'"

  def self.invoke
    # still don't know why both paths are needed
    system "ruby extconf.rb #{@@ob_flag} #{@@ob_version_flag}"
    system "make"
  end
end

if $0 == __FILE__
  begin
    Installer.invoke
  rescue
    # nothing yet
  end
end