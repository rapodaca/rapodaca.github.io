# Creates a makefile to build the Open Babel-Ruby extension.
# To be invoked by setup.rb.

require 'mkmf'

dir_config('openbabel')
dir_config('openbabel-2.0')
have_library('openbabel')

create_makefile('openbabel')
