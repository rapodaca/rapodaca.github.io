require 'openbabel'

conv = OpenBabel::OBConversion.new
conv.set_in_and_out_formats("smi", "mdl")

mol = OpenBabel::OBMol.new
conv.read_string(mol, 'c1ccccc1')

p mol.num_atoms # => 6 

mol.add_hydrogens

p mol.num_atoms # => 12
p mol.get_mol_wt # => 78.11184
