class SmilesController < ApplicationController
  def depict
    # Uses new input method.
    if params[:smiles]
      @smiles = params[:smiles]
    else
      @smiles = ''
    end
  end

  def image_for
    if flash[:bytes]
      send_data(flash[:bytes], :type => "image/png", :disposition => "inline", :filename => "#{flash[:smiles]}.png")
    end
  end

  def ajax_depict
    @smiles=request.raw_post
  end
end