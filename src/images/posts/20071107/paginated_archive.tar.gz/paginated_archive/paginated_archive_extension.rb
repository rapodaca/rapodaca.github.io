# Uncomment this if you reference any of your controllers in activate
# require_dependency 'application'

class PaginatedArchiveExtension < Radiant::Extension
  version "1.0"
  description "A paginated archive suitable for large blog-like archives"
  url "http://depth-first.com"
  
  # define_routes do |map|
  #   map.connect 'admin/paginated_archive/:action', :controller => 'admin/paginated_archive'
  # end
  
  def activate
    # admin.tabs.add "Paginated Archive", "/admin/paginated_archive", :after => "Layouts", :visibility => [:all]
    PaginatedArchive
  end
  
  def deactivate
    # admin.tabs.remove "Paginated Archive"
  end
  
end