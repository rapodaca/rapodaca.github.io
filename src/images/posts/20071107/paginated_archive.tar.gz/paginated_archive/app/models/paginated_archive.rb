# Uses Bruce Williams' Paginator Gem
# http://rubyforge.org/projects/paginator
require 'paginator'

class PaginatedArchive < Page
  include Radiant::Taggable

  description %{
    A simple paginated archive.
  }

  desc %{  
    The root of the pager tag heirarchy. Add a part named
    'config' to configure pagination. Currently two options
    are supported. Default values are defined as:

    <pre>
    items_per_page: 10
    invalid_page_redirect: '/'
    </pre>
  }
  tag 'pager' do |tag|
    children = tag.locals.page.children.sort{|x,y| y.published_at <=> x.published_at}
    config = YAML::load(render_part(:config))

    items_per_page = config['items_per_page']
    items_per_page ||= 10

    pager = ::Paginator.new(children.size, items_per_page) do |offset, per_page|
      children[offset, per_page]
    end

    redirect = config['invalid_page_redirect']
    redirect ||= '/'
    page = pager.page(@page_number)
    items = page.items

    if items
      @response.redirect(redirect) and return if items.empty? && @page_number != 1
    else
      @response.redirect(redirect) and return
    end

    tag.locals.pager = pager
    tag.locals.current_page = page

    tag.expand
  end

  desc %{  
    Returns the the page number for one of 'current',
    'first', 'last', 'next', and 'prev'

    *Usage:*
    <pre><code>
    <r:pager:page_number [page="current|first|last|prev|next]" />
    </code></pre>
  }
  tag 'pager:page_number' do |tag|
    page_name = tag.attr['page']

    page = case
      when page_name == 'current': tag.locals.current_page
      when page_name == 'first': tag.locals.current_page.first
      when page_name == 'last': tag.locals.current_page.last
      when page_name == 'prev': tag.locals.current_page.prev
      when page_name == 'next': tag.locals.current_page.next
    end

    page ? page.number : "Undefined page for name='#{page_name}' on page #{tag.locals.current_page.number}"
  end

  desc %{
    Returns the url for the first page.

    *Usage:*
    <pre><code>
    <r:pager:first />
    </code></pre>
  }
  tag 'pager:first' do |tag|
    tag.locals.page.url.chomp '/'
  end

  desc %{
    Returns the url for the last page.

    *Usage:*
    <pre><code>
    <r:pager:last />
    </code></pre>
  }
  tag 'pager:last' do |tag|
    "#{tag.locals.page.url.chomp('/')}?page=#{tag.locals.pager.last.number}"
  end

  desc %{
    Returns the url for the previous page.

    *Usage:*
    <pre><code>
    <r:pager:prev />
    </code></pre>
  }
  tag 'pager:prev' do |tag|
    params = tag.locals.current_page.prev? ? "#{tag.locals.page.url.chomp('/')}?page=#{tag.locals.current_page.prev.number}" : tag.locals.page.url

    params.gsub /\?page=1/, ''
  end

  desc %{
    Returns the url for the next page.

    *Usage:*
    <pre><code>
    <r:pager:next />
    </code></pre>
  }
  tag 'pager:next' do |tag|
    tag.locals.current_page.next? ? "#{tag.locals.page.url.chomp('/')}?page=#{tag.locals.current_page.next.number}" : tag.locals.page.url
  end

  desc %{
    Renders the containing elements unless the current
    page is first.

    *Usage:*
    <pre><code>
    <r:pager:unless_first />
    </code></pre>
  }
  tag 'pager:unless_first' do |tag|
    tag.expand unless tag.locals.current_page.number == 1
  end

  tag 'pager:if_first' do |tag|
    tag.expand if tag.locals.current_page.number == 1
  end

  desc %{
    Renders the containing elements unless the current
    page is last.

    *Usage:*
    <pre><code>
    <r:pager:unless_last />
    </code></pre>
  }
  tag 'pager:unless_last' do |tag|
    tag.expand unless tag.locals.current_page.number == tag.locals.pager.last.number
  end

  tag 'pager:if_last' do |tag|
    tag.expand if tag.locals.current_page.number == tag.locals.pager.last.number
  end

  desc %{
    Renders the containing elements unless there is a
    previous page.

    *Usage:*
    <pre><code>
    <r:pager:unless_prev />
    </code></pre>
  }
  tag 'pager:unless_prev' do |tag|
    tag.expand unless tag.locals.current_page.prev?
  end

  tag 'pager:if_prev' do |tag|
    tag.expand  if tag.locals.current_page.prev?
  end

  desc %{
    Renders the containing elements unless there is a
    next page.

    *Usage:*
    <pre><code>
    <r:pager:unless_next />
    </code></pre>
  }
  tag 'pager:unless_next' do |tag|
    tag.expand unless tag.locals.current_page.next?
  end

  desc %{
    Renders the containing elements if there is a
    next page.

    *Usage:*
    <pre><code>
    <r:pager:if_next />
    </code></pre>
  }
  tag 'pager:if_next' do |tag|
    tag.expand if tag.locals.current_page.next?
  end

  desc %{  
    Iterates over the children in the current page. Inside
    this tag, all page attribute tags are mapped to the
    current child page.

    *Usage:*
    <pre><code>
    <r:pager:each_child>
     ...
    </r:pager:each_child>
    </code></pre>
  }
  tag 'pager:each_child' do |tag|
    result = []

    tag.locals.current_page.items.each do |item|
      tag.locals.child = item
      tag.locals.page = item
      result << tag.expand
    end 

    result
  end

  # URL parameters get ignored, so we need to render fresh
  # everytime.
  def cache?
    false
  end

  # Overrides Page.process.
  def process(request, response)
    @page_number = request.query_parameters['page'] ? request.query_parameters['page'].to_i : 1
    @response = response
    @request = request

    super(request, response)
  end

  # Copied from class ArchivePage - couldn't inherit from
  # that class for some reason.
  def child_url(child)
    date = child.published_at || Time.now
    clean_url "#{ url }/#{ date.strftime '%Y/%m/%d' }/#{ child.slug }"
  end
  
  # Copied from class ArchivePage - couldn't inherit from that
  # class for some reason.
  def find_by_url(url, live = true, clean = false)
    url = clean_url(url) if clean
    if url =~ %r{^#{ self.url }(\d{4})(?:/(\d{2})(?:/(\d{2}))?)?/?$}
      year, month, day = $1, $2, $3
      children.find_by_class_name(
        case
        when day
          'ArchiveDayIndexPage'
        when month
          'ArchiveMonthIndexPage'
        else
          'ArchiveYearIndexPage'
        end
      )
    else
      super
    end
  end
end

